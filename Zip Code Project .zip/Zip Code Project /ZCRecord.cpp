//
//  ZCRecord.cpp
//  Zip Code Project
//
//  Created by Eli  on 2/20/22.
//

#include "ZCRecord.h"
//----------------------------------------------------------------------------
    /// @brief Default constructor
    /// @pre  None
    /// @post the fields been set to empty
ZCRecord::ZCRecord ()
{
    Clear ();
}
    /// @brief Clear
    /// set the field to empty string
    /// @pre   none
    /// @post  the field was set to empty
void ZCRecord::Clear ()
{
    /// set each field to an empty string
    ZipCode [0] = 0;
    PlaceName [0] = 0;
    State [0] = 0;
    County [0] = 0;
    Latitude [0] = 0;
    Longitude [0] = 0;
}
    /// @brief Pack
    /// pack the fields into a DelimTextBuffer, return TRUE if all succeed, FALSE o/w
    /// @param Delimiter text buffer
    /// @pre   none
    /// @post  all fields packed with delimiters, return TRUE if packing succeed, FALSE o/w
    /// @return TRUE if packing succeed, FALSE o/w
int ZCRecord::Pack (DelimTextBuffer & Buffer) const
{
    int result;
    Buffer . Clear ();
    result = Buffer . Pack (ZipCode);
    result = result && Buffer . Pack (PlaceName);
    result = result && Buffer . Pack (State);
    result = result && Buffer . Pack (County);
    result = result && Buffer . Pack (Latitude);
    result = result && Buffer . Pack (Longitude);
    return result;
}
    /// @brief Unpack
    /// extract data from the DelimTextBuffer to the fields, return TRUE if all succeed, FALSE o/w
    /// @param Delimiter text buffer
    /// @pre   fields are packed with proper delimiters
    /// @post  return TRUE if unpacking succeed, FALSE o/w
    /// @return TRUE if all succeed, FALSE o/w
int ZCRecord::Unpack (DelimTextBuffer & Buffer)
{
    Buffer.NextByteReset();
    int result;
    result = Buffer . Unpack (ZipCode);
    result = result && Buffer . Unpack (PlaceName);
    result = result && Buffer . Unpack (State);
    result = result && Buffer . Unpack (County);
    result = result && Buffer . Unpack (Latitude);
    result = result && Buffer . Unpack (Longitude);
    return result;
}
    /// @brief Print
    /// print out the fields in output
    /// @param output stream,
    /// @pre   none
    /// @post  the fields are printed out by lines
void ZCRecord::Print (ostream & stream)
{
    stream << "ZCRecord:"
        << "\t PlaceName '" <<PlaceName<<"'\n"
        << "\t County '" <<County<<"'\n"
        << "\t Longitude '"<<Longitude<<"'\n"
        << "\t Latitude '"<<Latitude<<"'\n"
        << "\t     State '"<<State<<"'\n"
        << "\t  Zip Code '"<<ZipCode<<"'\n" <<flush;
}
