//
//  main.cpp
//  Zip Code Project
//
//  Created by Eli  on 2/15/22.
//

#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>
#include <cstdlib>
#include "deltext.h"
#include "ZCRecord.h"

using namespace std;

/// @brief a constant for the width of the display for zipcode feilds
const int DISP_ZIP = 15;
/// @brief a constant for the width of the display
const int DISP_STATE = 10;
///@brief the total number of states
const int NUMSTATES = 57;
///@brief All of the state in alphabetical order by abbr. Including DC
const string STATE_LIST[NUMSTATES] = {"AA","AK","AL","AP","AR","AZ","CA"
                        ,"CO","CT","DC","DE","FL","FM"
                        ,"GA","HI","IA","ID","IL"
                        ,"IN","KS","KY","LA","MA"
                        ,"MD","ME","MH","MI","MN","MO"
                        ,"MP","MS","MT","NC","ND","NE"
                        ,"NH","NJ","NM","NV","NY"
                        ,"OH","OK","OR","PA","PW","RI"
                        ,"SC","SD","TN","TX","UT"
                        ,"VA","VT","WA","WI","WV","WY"};


/// @brief A helper function that displays the final sorted zipcode table
/// @arg arr, a 2D array with dimensions 51x4
/// @pre arr contains a valid and complete 51x4 ZCRecord
/// @post Displays the final output table of zipcodes.
void display(ZCRecord arr[][4])
{
//Headers
    cout << setw(DISP_STATE)<< left << " State ID";
    cout << setw(DISP_ZIP)  << left << " Northernmost";
    cout << setw(DISP_ZIP)  << left << " Southernmost";
    cout << setw(DISP_ZIP)  << left << " Easternmost";
    cout << setw(DISP_ZIP)  << left << " Westernmost" <<endl;
    //display table
    for (int i = 0; i < NUMSTATES; i++)
    {
        cout << setw(DISP_STATE)<< left << "  " + STATE_LIST[i];
        for (int j = 0; j < 4; j++)
        {
            cout<< setw(DISP_ZIP) << left << arr[i][j].ZipCode;
        }
        cout <<endl;
    }
}

/// @brief Takes a state ID and outputs an integer representing it's index in an alphabatized list.
///        i.e. "AK" (Alaska) would return 0, and "WY" (Wyoming) would return 50;
/// @pre abbr is a three (3) character state ID char array.
/// @return the integer index where the state would be in an alphabatized list, or -1 if not found
int stateToInt(char abbr[]){
    //loop over array
    for (int i = 0; i < NUMSTATES; i++){
        //if you find a match, output it's index.
        if (abbr[0]==STATE_LIST[i][0] && abbr[1]==STATE_LIST[i][1])
            return i;
    }
    cerr << "Warn: State " << abbr[0] << abbr[1] << " not found!"<<endl;
    //NOTE! if the state's not found, this return could cause a problem if not handled!
    return -1;
}

int main()
{
   fstream file;
   file.open("us_postal_codes.csv");
   string reader;
   char* s2;
   DelimTextBuffer buffer;
   ZCRecord r;
   ZCRecord RecordArray[NUMSTATES][4];
   while(file.good())
   {
        getline(file,reader);
        s2 = new char[reader.length() + 1];
        strcpy(s2, reader.c_str());
        buffer.Clear();
        buffer.Pack(s2);
        //Dump s2 after use!
        delete[] s2;
        r.Unpack(buffer);
        if(RecordArray[stateToInt(r.State)][0].State[0] != 0)
        {
           if(atof(r.Latitude) > atof(RecordArray[stateToInt(r.State)][0].Latitude))
            {
               RecordArray[stateToInt(r.State)][0] = r;
            }
        }
        else{RecordArray[stateToInt(r.State)][0] = r;}


        if(RecordArray[stateToInt(r.State)][1].State[0] != 0)
        {
            if(atof(r.Latitude) < atof(RecordArray[stateToInt(r.State)][1].Latitude))
            {
                RecordArray[stateToInt(r.State)][1] = r;
            }
        }
        else{RecordArray[stateToInt(r.State)][1] = r;}


        if(RecordArray[stateToInt(r.State)][2].State[0] != 0)
        {
            if(atof(r.Latitude) > atof(RecordArray[stateToInt(r.State)][2].Longitude))
            {
                RecordArray[stateToInt(r.State)][2] = r;
            }
        }
        else{RecordArray[stateToInt(r.State)][2] = r;}


        if(RecordArray[stateToInt(r.State)][3].State[0] != 0)
        {
            if(atof(r.Latitude) < atof(RecordArray[stateToInt(r.State)][3].Longitude))
            {
                RecordArray[stateToInt(r.State)][3] = r;
            }
        }
        else{RecordArray[stateToInt(r.State)][3] = r;}

   }
   display(RecordArray);
   return 0;
}
