//
//  ZCRecord.h
//  Zip Code Project
//
//  Created by Eli  on 2/20/22.
//

#ifndef ZCRecord_h
#define ZCRecord_h
#include <iostream>
#include "deltext.h"
using namespace std;
class ZCRecord
{
  public:
    /// fields
    /// @brief char array for zipcode of the record
    char ZipCode [10];
    /// @brief char array for Place Name of the record
    char PlaceName [30];
    /// @brief char array for State Id of the record
    char State [3];
    /// @brief char array for County of the record
    char County [20];
    /// @brief char array for Latitude of the record
    char Latitude [12];
    /// @brief char array for Longitude of the record
    char Longitude [12];
    //----------------------------------------------------------------------------
    /// @brief Default constructor
    /// @pre  None
    /// @post the fields been set to empty
    ZCRecord ();
    /// @brief Clear
    /// set the field to empty string
    /// @pre   none
    /// @post  the field was set to empty
    void Clear ();
    /// @brief Unpack
    /// extract data from the DelimTextBuffer to the fields, return TRUE if all succeed, FALSE o/w
    /// @param Delimiter text buffer
    /// @pre   fields are packed with proper delimiters
    /// @post  return TRUE if unpacking succeed, FALSE o/w
    /// @return TRUE if all succeed, FALSE o/w
    int Unpack (DelimTextBuffer &);
    /// @brief Pack
    /// pack the fields into a DelimTextBuffer, return TRUE if all succeed, FALSE o/w
    /// @param Delimiter text buffer
    /// @pre   none
    /// @post  all fields packed with delimiters, return TRUE if packing succeed, FALSE o/w
    /// @return TRUE if packing succeed, FALSE o/w
    int Pack (DelimTextBuffer &) const;
    /// @brief Print
    /// print out the fields in output
    /// @param output stream,
    /// @pre   none
    /// @post  the fields are printed out by lines
    void Print (ostream &);
};

#endif /* ZCRecord_h */
